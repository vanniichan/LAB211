/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Strongest
 */
public class calculatorManagerTest {
    
    public calculatorManagerTest() {
    }

    @Test
    public void testAddtionMatrix() {
    }

    @Test
    public void testSubtractionMatrix() {
    }

    @Test
    public void testMultiplicationMatrix() {
    }

    @Test
    public void testDisplayMatrixInput() {
    }
    
}
