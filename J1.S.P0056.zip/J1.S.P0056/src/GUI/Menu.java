/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Manage.Management;
import Manage.Validation;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Menu {

    private static String[] ops = {
        "Add Worker",
        "Up salary",
        "Down salary",
        "Display information salary",
        "Exit"
    };
    
    public static int getChoice(){
        Scanner sc= new Scanner(System.in);
        for(int i=0; i<ops.length; i++)
            System.out.println((i+1 + ". "+ ops[i]));
        
        return Validation.getInt("Your choice: ", 1, ops.length);
    }
    
    public static void display(){
        Management m = new Management();
        int choice;
        do{
            System.out.println("====Worker Management====");
            choice=getChoice();
            switch(choice){
                case 1:
                    m.addWorker();
                    break;
                case 2:
                    m.updateSalary(1);
                    break;
                case 3:
                    m.updateSalary(2);
                    break;
                case 4:
                    m.getInformation();
                    break;
                case 5:
                    break;
            }
        }while(choice != 5);
    }
}
