/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0052;

/**
 *
 * @author DELL
 */
public class J1SP0052 {

    public static void main(String[] args) {
        Manager ma = new Manager();
        while (true) {
            int choice = ma.showMenuAndChoice(); 
            switch (choice) {
                case 1:
                    ma.addContry();
                    break;
                case 2:
                    ma.displayList();
                    break;
                case 3:
                    ma.searchByName();
                    break;
                case 4:
                    ma.SortAcendingbyName();
                    break;
                case 5:
                    return;
            }
        }

    }

}
